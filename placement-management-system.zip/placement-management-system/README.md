# Placement Management System

A single-page CRUD web app for a campus placement cell: manage **Students**,
**Companies**, and **Applications** (which student applied where, and their
status through the hiring pipeline).

## Tech stack

- HTML, CSS, vanilla JavaScript — no build step, no dependencies.
- Data layer: an `API` object (`API.students`, `API.companies`,
  `API.applications`), each with `getAll / create / update / delete`,
  backed by the browser's `localStorage` in place of a live database.
  It mirrors what a REST API looks like (`GET/POST/PUT/DELETE
  /api/students/`), so swapping in a real Django or Spring Boot backend
  later means replacing this object with `fetch()` calls — the UI code
  doesn't change.

## Project structure

```
placement-management-system/
├── index.html      # entire app: markup, styles, and script
└── README.md
```

## Running it in VS Code

1. Unzip this folder and open it in VS Code (`File → Open Folder…`).
2. Install the **Live Server** extension (by Ritwick Dey) if you don't
   have it — Extensions panel, search "Live Server".
3. Right-click `index.html` in the Explorer → **Open with Live Server**.
   It'll open at something like `http://127.0.0.1:5500`.
   - No Live Server? Just double-click `index.html` to open it directly
     in a browser — everything still works, since there's no server-side
     code to run.

## Testing checklist

**Create**
- Add a student with a blank name, a duplicate roll number, or an
  invalid email → each field should highlight red and the record should
  not save.
- Add a valid student, then a valid company → both should appear in
  their tables immediately, and the sidebar counts should update.

**Read**
- Type into the Students search box (try a name, a roll number, and a
  department) → the table should narrow to matches only.
- Filter Applications by status (e.g. "Selected") → only matching rows
  show.
- Search for something that matches nothing → confirm the "no records"
  empty state appears instead of a blank table.

**Update**
- Edit a student's CGPA or an application's status → confirm the table
  row updates and, for status changes, the Dashboard's "Offers made"
  and average package figures recalculate.

**Delete**
- Try deleting a student or company that has an application on record →
  it should be blocked with a message.
- Delete the application first, then the student/company → it should
  now succeed.

**Validation edge cases**
- CGPA outside 0–10, a package ≤ 0, a phone number that isn't 10
  digits, two applications for the same student+company pair — each
  should be rejected.

**Persistence**
- Refresh the page (or close and reopen the tab) → all data should
  still be there, since it's saved to `localStorage`.

**Responsiveness**
- Resize the browser window down to a phone width → the sidebar should
  collapse into a horizontal top bar.

## Extending to a real backend

If your assignment calls for the full stack in the SOP (Django REST
Framework or Spring Boot + a real database, tested with Postman), this
frontend is built to drop onto that: point the `API` object's methods
at your REST endpoints instead of `localStorage`, keep the same method
names, and the rest of the app keeps working unchanged.
